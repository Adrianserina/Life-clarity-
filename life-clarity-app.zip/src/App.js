import React, { useState } from "react";

const App = () => {
  const [goal, setGoal] = useState("");
  const [steps, setSteps] = useState([]);

  const handleGoalChange = (e) => setGoal(e.target.value);

  const generateSteps = () => {
    const defaultSteps = [
      "Define the end goal in vivid detail.",
      "Break it into milestones.",
      "Assign timelines to each milestone.",
      "List required resources (tools, people, money).",
      "Plan your daily/weekly actions.",
      "Track progress and adjust as needed.",
    ];
    setSteps(defaultSteps);
  };

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h1>Life Clarity Generator</h1>
      <input
        type="text"
        value={goal}
        onChange={handleGoalChange}
        placeholder="What's your goal?"
        style={{ padding: 10, width: "100%" }}
      />
      <button onClick={generateSteps} style={{ marginTop: 10 }}>
        Break It Down
      </button>
      <ul>
        {steps.map((step, i) => (
          <li key={i}>{step}</li>
        ))}
      </ul>
    </div>
  );
};

export default App;